# BuildBuddy Enterprise Cache Proxy

BuildBuddy Enterprise Cache Proxy is a caching layer that sits in front of your
[BuildBuddy](https://buildbuddy.io) remote cache, serving frequently-requested
blobs locally and reducing round-trips to the upstream cache.

## TL;DR

```bash
helm repo add buildbuddy https://helm.buildbuddy.io
helm install buildbuddy-cache-proxy buildbuddy/buildbuddy-enterprise-cache-proxy
```

## Introduction

This chart creates a [BuildBuddy Enterprise Cache Proxy](https://www.buildbuddy.io)
deployment on a [Kubernetes](https://kubernetes.io/) cluster using the
[Helm](https://helm.sh/) package manager.

## Prerequisites

- Kubernetes 1.19+
- Helm v3+

## Defaults

This chart runs the Cache Proxy using BuildBuddy-recommended settings.

## Installing the Chart

To install the chart with the release name `my-release`:

```bash
helm install my-release buildbuddy/buildbuddy-enterprise-cache-proxy
```

See [Configuration](#configuration) below for values you may want to override.

## Uninstalling the Chart

```bash
helm delete my-release
```

## Telemetry

When the Cache Proxy registers with the BuildBuddy backend, it appears on the
Cache Proxies page of the BuildBuddy UI. It also keeps a connection open to and
reports the following information:

- **Identity:** hostname, a randomly generated proxy ID, a persistent host ID,
  version, OS, architecture, start time, and the labels configured in
  `config.cache_proxy.labels`.
- **Resources:** allocated CPU and memory.
- **Configuration:** flags set to non-default values. The values of secret
  flags (such as API keys) are redacted.
- **Statistics:** cumulative cache hit, miss, and write counts and byte totals.

This information is only visible to organization and server admins. Admins can
also gather Go runtime profiles (CPU, heap, and goroutine) from running proxies
using the BuildBuddy UI. Profiles are only collected when requested. Profiles
show which code is running, where memory is allocated, and what goroutines are
running. Profiles never include cached blobs. These remotely-gathered profiles
can be disabled by setting `--cache_proxy.allow_remote_profiling=false`.

## Configuration

See [values.yaml](./values.yaml) for the full list of configurable parameters.
Some common ones:

| Parameter                              | Description                                                              | Default                                                 |
| -------------------------------------- | ------------------------------------------------------------------------ | ------------------------------------------------------- |
| `image.repository`                     | Container image repository                                               | `buildbuddy.bbcr.io/public/buildbuddy-proxy-enterprise` |
| `image.tag`                            | Container image tag                                                      | `enterprise-v2.323.0`                                   |
| `replicas`                             | Number of cache-proxy replicas                                           | `3`                                                     |
| `cacheTarget`                          | Upstream BuildBuddy cache the proxy sits in front of                     | `grpcs://remote.buildbuddy.io`                          |
| `config.cache_proxy.intercept_and_chunk_large_writes` | Chunk large client uploads for local storage and upstream transfer; requires a CDC-capable upstream. Client-to-proxy traffic is unchanged | `true` |
| `config.cache_proxy.labels`            | Application registration labels shown in the proxy UI. An explicit map replaces the default; `{}` disables it. Use a short custom label for namespaces over 50 characters or to distinguish releases in the same namespace. At most 20 labels, with keys and values at most 50 characters each. | `{namespace: <release namespace>}` for namespaces up to 50 characters; otherwise none |
| `config.auth.reparse_jwts`             | Disable process-local JWT reparsing for remote-authenticated proxies     | `false`                                                 |
| `config.cache.pebble.min_eviction_age` | Minimum idle time before an entry can be evicted under capacity pressure | `0h`                                                    |
| `config.cache.distributed_cache.listen_addr` | Distributed-cache address; must match the discovered peer address for local reads | `${MY_IP}:5151` (IPv4) |
| `resources`                            | Pod CPU/memory requests and limits                                       | `4 CPU / 16Gi`                                          |
| `config`                               | The `config.yaml` contents passed to the cache proxy                     | See [values.yaml](./values.yaml)                        |
| `ingress.annotations`                  | Extra annotations merged into the cache-proxy gRPC Ingress               | `proxy-body-size: "0"`                                  |
| `rbac.create`                          | Create the Role/RoleBinding used for Kubernetes peer discovery           | `true`                                                  |
| `serviceAccount.create`                | Create the ServiceAccount used by cache-proxy pods                       | `true`                                                  |
| `podDisruptionBudget.enabled`          | Enable a PodDisruptionBudget                                             | `true`                                                  |
| `persistence.enabled`                  | Back the cache-proxy data volume with a per-replica PVC                  | `false`                                                 |
| `persistence.size`                     | Size of each cache-proxy PVC                                             | `100Gi`                                                 |
| `persistence.storageClass`             | StorageClass for the cache-proxy PVCs (cluster default if unset)         | `nil`                                                   |

For CDC, we recommend that server operators configure
`config.cache.chunking.ac_key_salt` with a stable random secret shared by all
app servers and cache proxies, as described in the
[CDC configuration guide](https://www.buildbuddy.io/docs/config-rbe#content-defined-chunking).
Changing or removing it makes existing chunked-only manifests unavailable.

Individual values can be overridden at install time with `--set`:

```bash
helm install my-release buildbuddy/buildbuddy-enterprise-cache-proxy \
  --set replicas=3 \
  --set config.cache.max_size_bytes=250000000000
```

### Peer discovery

The Cache Proxy uses consistent hashing to shard replicas across pods. Peer
discovery is done via the Kubernetes API. The chart creates a `ServiceAccount`,
`Role`, and `RoleBinding` granting the minimum permissions needed
(`get/list/watch pods`, `get replicasets` in the release namespace).

For IPv6 pods, override the listener address to enclose the pod IP in brackets:

```yaml
config:
  cache:
    distributed_cache:
      listen_addr: "[${MY_IP}]:5151"
```

If you prefer to manage RBAC yourself, set `rbac.create=false` and
`serviceAccount.create=false`, and reference your existing ServiceAccount with
`serviceAccount.name`.

### Persistent storage

By default the cache proxy writes its on-disk cache to an `emptyDir`, so the
cache is cold again every time a pod restarts. To keep the cache across
restarts and rescheduling, enable persistence:

```bash
helm install my-release buildbuddy/buildbuddy-enterprise-cache-proxy \
  --set persistence.enabled=true \
  --set persistence.size=250Gi \
  --set persistence.storageClass=ssd
```

This adds a `volumeClaimTemplate` to the StatefulSet, so each replica gets its
own PersistentVolumeClaim mounted at `/buildbuddy/` — the directory holding
`config.cache.pebble.root_directory`. Size the volume comfortably above
`config.cache.max_size_bytes`.

Prefer a local SSD StorageClass over a network-attached one for the better
performance charateristics of the former. Data lost due to node failures can be
repopulated from the backing cache. If you want the proxy itself to survive
losing a replica (during deployments, for example), set
`config.cache.distributed_cache.replication_factor` so blobs are held on more
than one pod. This is cheaper and faster than paying for replication in the
storage layer.

Pick these settings before you install. Kubernetes does not allow a
StatefulSet's `volumeClaimTemplates` to change after creation, so later edits to
any `persistence.*` value — including turning it back off — make `helm upgrade`
fail with `updates to statefulset spec for fields other than ... are forbidden`.
To change them, delete the StatefulSet with `kubectl delete statefulset
<name> --cascade=orphan` and re-run the upgrade; the pods and PVCs will survive,
so no cache data is lost.

Kubernetes does not garbage-collect PVCs created from a `volumeClaimTemplate`:
they outlive `helm uninstall` and scale-downs, and are reattached if a replica
comes back. Delete them by hand when you no longer need the data.

As an alternative, `cacheProxyDataVolumeHostPath` mounts a path on the node
(useful for local SSDs). The two options are mutually exclusive.
